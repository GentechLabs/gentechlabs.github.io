---
name: multi-agent-profile-setup
description: "Create or restore multi-agent Hermes setups: profiles, SOUL.md, Telegram tokens, TTS voices, cron jobs."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [multi-agent, profiles, telegram, setup, restoration]
    related_skills: [hermes-agent]
---

# Multi-Agent Profile Setup

Restore or create multiple Hermes agent profiles with Telegram gateways, unique personalities, TTS voices, and cron jobs. Use when setting up a team of agents (e.g. GenTech Labs pattern: CEO + department heads).

## When to Use

- Restoring a multi-agent setup from backup configs
- Creating multiple Hermes profiles with different roles
- Setting up per-agent Telegram bots with unique personalities
- Configuring per-agent TTS voices and cron schedules
- Switching model / provider for all existing agents in bulk (e.g., mimo-v2.5/opencode-go --> kimi-k2.6/ollama-cloud)
- Diagnosing and fixing 429 "Too Many Concurrent Requests" errors when multiple agents share a single provider API key
- Staggering cron jobs across profiles to prevent provider-side rate-limit collisions

## Workflow

### 1. Discover Backup Configs

Look for existing configs in common locations:
```bash
find /root -maxdepth 4 -name "config.yaml" -path "*hermes*" 2>/dev/null
find /root -maxdepth 4 -name "SOUL.md" 2>/dev/null
find /root -maxdepth 4 -name "jobs.json" -path "*cron*" 2>/dev/null
ls /root/repos/*/profiles/ 2>/dev/null
ls /root/vaults/*/ 2>/dev/null  # Obsidian vaults
```

### 2. Create Profiles

```bash
hermes profile create <name> --clone
```

Each profile gets its own:
- `~/.hermes/profiles/<name>/config.yaml`
- `~/.hermes/profiles/<name>/SOUL.md`
- `~/.hermes/profiles/<name>/.env`
- `~/.hermes/profiles/<name>/cron/jobs.json`
- Wrapper script at `~/.local/bin/<name>`

### 3. Copy Backup Configs

```bash
for agent in agent1 agent2 agent3; do
  cp /backup/path/profiles/$agent/config.yaml ~/.hermes/profiles/$agent/config.yaml
  cp /backup/path/profiles/$agent/SOUL.md ~/.hermes/profiles/$agent/SOUL.md
done
```

### 4. Set Telegram Bot Tokens and Allowed Users

Each agent needs its own bot from @BotFather:
```bash
echo 'TELEGRAM_BOT_TOKEN=<token>' > ~/.hermes/profiles/<name>/.env
```

Set allowed users (comma-separated Telegram user IDs):
```bash
echo 'TELEGRAM_ALLOWED_USERS=7105876857,6842745592' >> ~/.hermes/profiles/<name>/.env
```
Without this, all unauthorized users are denied and agents won't respond.
Find IDs via @userinfobot on Telegram.

### 5. Set Model and API Keys (Critical)

Check all profiles use the same model AND provider:
```bash
for agent in *; do
  sed -i 's|default: old-model|default: mimo-v2.5|' ~/.hermes/profiles/$agent/config.yaml
  sed -i 's|provider: old-provider|provider: opencode-go|' ~/.hermes/profiles/$agent/config.yaml
done
```

The provider API key MUST be in each profile's .env — it is NOT inherited from the main profile:
```bash
for agent in *; do
  echo 'OPENCODE_GO_API_KEY=<key>' >> ~/.hermes/profiles/$agent/.env
done
```
Without this, agents crash on first message with "Provider X set but no API key found".

### 6. Configure TTS Voices

Each agent gets a unique ElevenLabs voice. Update `voice_id` in config.yaml:
```bash
# Find the elevenlabs section and update voice_id per agent
sed -i 's|voice_id: OLD_ID|voice_id: NEW_ID|' ~/.hermes/profiles/<name>/config.yaml
```

Voice config reference:
- `voice_id` under `tts.elevenlabs` in config.yaml
- Test voices via ElevenLabs API before assigning

### 7. Restore Cron Jobs

```bash
mkdir -p ~/.hermes/profiles/<name>/cron
cp /backup/path/profiles/<name>/cron/jobs.json ~/.hermes/profiles/<name>/cron/jobs.json
```

Cron jobs inherit model from profile config — no per-job model override needed.

### 8. Set Home Channels and Shared Resources

Set the home channel for each agent (cron jobs deliver here):
```bash
echo 'TELEGRAM_HOME_CHANNEL=-100386354028' >> ~/.hermes/profiles/gentech/.env
echo 'TELEGRAM_HOME_CHANNEL=-1002916759037' >> ~/.hermes/profiles/yoyo/.env
```
Without this, cron jobs have no delivery target and won't post.

Other shared resources:
```bash
# Obsidian vault
echo 'OBSIDIAN_VAULT_PATH=/path/to/vault' >> ~/.hermes/profiles/<name>/.env

# ElevenLabs API key
echo 'ELEVENLABS_API_KEY=<key>' >> ~/.hermes/profiles/<name>/.env
```

### 10. Bulk Model / Provider Reconfiguration

When switching models or providers for an already-running fleet (e.g., `mimo-v2.5/opencode-go` → `kimi-k2.6/ollama-cloud`), use this ordered workflow to avoid crashes from partial updates.

> **Note on cron job overrides:** Some cron jobs may have explicit `model` and/or `provider` fields that override the profile default. These do NOT automatically follow the profile model change. You must update them explicitly (see step H below).

**A. Stop all gateways** — never reconfigure a running gateway:
```bash
for agent in gentech yoyo dmob desmond; do
  hermes gateway stop --profile "$agent"
done
```

**B. Propagate credential pool to every profile** — provider credentials are NOT inherited across profiles. Copy the new provider's auth pool from the default `auth.json` into each profile:
```bash
# Extract the provider pool from default auth.json
python3 -c "
import json, sys
creds = json.load(open('~/.hermes/auth.json'))
pool = next((p for p in creds.get('credential_pools',[]) if p['provider']=='ollama-cloud'), None)
if pool: json.dump({'credential_pools': [pool]}, sys.stdout, indent=2)
" > /tmp/new_pool.json

for agent in gentech yoyo dmob desmond; do
  cp /tmp/new_pool.json ~/.hermes/profiles/$agent/auth.json
done
```

Also copy any required API key from the default `.env` to each profile:
```bash
source ~/.hermes/.env
for agent in gentech yoyo dmob desmond; do
  echo "OLLAMA_API_KEY=$OLLAMA_API_KEY" >> ~/.hermes/profiles/$agent/.env
done
```

**C. Update profile configs** in one shot:
```bash
for agent in gentech yoyo dmob desmond; do
  cfg=~/.hermes/profiles/$agent/config.yaml
  # Set model and provider
  python3 -c "
import yaml
with open('$cfg') as f: c = yaml.safe_load(f)
c['model']['default'] = 'kimi-k2.6'
c['model']['provider'] = 'ollama-cloud'
with open('$cfg','w') as f: yaml.dump(c, f, sort_keys=False)
"
done
```

**D. Restore cron jobs from backup** — cron jobs do not survive reinstalls. Copy vault backups into each profile:
```bash
for agent in gentech yoyo dmob desmond; do
  mkdir -p ~/.hermes/profiles/$agent/cron
  cp /root/vaults/gentech/00-System/agent-profiles/$agent/cron/jobs.json \
     ~/.hermes/profiles/$agent/cron/jobs.json
  # Verify JSON is valid before the gateway loads it
  python3 -m json.tool ~/.hermes/profiles/$agent/cron/jobs.json > /dev/null
  echo "$agent: jobs.json OK"
done
```

**E. If JSON validation fails** — backup files can get corrupted (truncated prompts, quote issues). Fix the corrupted entry by:
> 1. Running `python3 -m json.tool broken_file.json` to get line number
> 2. Looking at the raw JSON around that line
> 3. Replacing the broken prompt with a valid one from another agent's same job ID, or reconstructing it as a single-line JSON string with proper escaping (`\n` not actual newlines)

**F. Restart all gateways**:
```bash
for agent in gentech yoyo dmob desmond; do
  hermes gateway restart --profile "$agent"
done
```

**G. Verify** — confirm all agents report the new model/provider and cron counts match vault records:
```bash
for agent in gentech yoyo dmob desmond; do
  echo "=== $agent ==="
  hermes gateway status --profile "$agent" | grep -E 'Active|Status'
  hermes cron list --profile "$agent" | grep -c active
done
```

**H. Update Cron Job Overrides** — if any cron jobs have explicit `model` or `provider` fields, update them to match the new provider/model. These overrides are NOT automatically changed by profile config updates.
```bash
# Bulk-update all cron overrides across profiles
for agent in gentech yoyo dmob desmond; do
  cfg=~/.hermes/profiles/$agent/cron/jobs.json
  python3 -c "
import json
with open('$cfg') as f: d = json.load(f)
for job in d.get('jobs', []):
    changed = False
    if job.get('model') and job['model'] != 'stepfun/step-3.5-flash':
        job['model'] = 'stepfun/step-3.5-flash'
        changed = True
    if job.get('provider') and job['provider'] != 'nous':
        job['provider'] = 'nous'
        changed = True
    if changed:
        with open('$cfg', 'w') as f: json.dump(d, f, indent=2)
print(f'Updated {sum(1 for j in d.get(\"jobs\",[]) if j.get(\"model\") or j.get(\"provider\"))} jobs with overrides')
"
done
```

**I. Set Auxiliary Vision Model** (if using a multimodal chat model for image analysis): Update the auxiliary vision configuration in each profile to use the same model.
```bash
for agent in gentech yoyo dmob desmond; do
  cfg=~/.hermes/profiles/$agent/config.yaml
  python3 -c "
import yaml
with open('$cfg') as f: c = yaml.safe_load(f)
c.setdefault('auxiliary', {})
c['auxiliary']['vision'] = {
    'provider': 'nous',
    'model': 'stepfun/step-3.5-flash',
    'base_url': '',
    'api_key': '',
    'timeout': 120,
    'extra_body': {},
    'download_timeout': 30
}
with open('$cfg', 'w') as f: yaml.dump(c, f, sort_keys=False)
"
done
```

Install systemd services first (one-time):
```bash
for agent in agent1 agent2 agent3; do
  hermes -p $agent gateway install
done
```

Then start:
```bash
for agent in agent1 agent2 agent3; do
  hermes -p $agent gateway start
done
```

## Rate Limiting & Concurrency Mitigation

When multiple agent profiles share a single API key (e.g., one `OLLAMA_API_KEY` across 4 agents + 68 cron jobs), provider-side concurrency limits cause 429 "Too Many Concurrent Requests." This section covers diagnosis and mitigation.

### Diagnosis

Check which provider is throwing 429s and why:

```bash
# Review recent error patterns in gateway logs
for agent in gentech yoyo dmob desmond; do
  echo "=== $agent ==="
  grep -i "429\|concurrent\|Too Many\|rate_limit" ~/.hermes/profiles/$agent/logs/agent.log | tail -5
done

# Check credential pool exhaustion status
for agent in gentech yoyo dmob desmond; do
  python3 -c "
import json
with open(f'~/.hermes/profiles/{agent}/auth.json') as f: d=json.load(f)
pool = d.get('credential_pool',{})
for prov, entries in pool.items():
  for e in entries:
    print(f'{agent} / {prov}: status={e.get('last_status')} code={e.get('last_error_code')} msg={e.get('last_error_message','')[:60]}')
"
done

# Count overlapping cron schedules to find collision windows
for agent in gentech yoyo dmob desmond; do
  cat ~/.hermes/profiles/$agent/cron/jobs.json | python3 -c "
import sys,json
jobs = json.load(sys.stdin).get('jobs',[])
for j in jobs:
    s = j.get('schedule',{})
    print(j['id'][-12:], s.get('display') or s.get('expr','?'))
"
done | sort -k2
```

**Key indicators you are hitting provider-side concurrency limits:**
- Error message contains "Too Many Concurrent Requests" or "concurrent"
- Only occurs during aligned cron windows (e.g., :00, :05, :10 when multiple agents have `*/5` jobs)
- Works fine when agents are tested individually but fails when all gateways are running simultaneously
- Credential pool shows `exhausted` but not `billing` exhaustion

### Mitigation Strategies (pick one or combine)

#### Strategy A: Stagger Cron Jobs by Profile

Offset the minute field per agent so their cron firing windows never overlap. Add a fixed offset unique to each agent:

```bash
# Per-profile minute offsets
# Gentech -> offset 0 (fires at :00, :05, :10...)
# YoYo   -> offset 1 (fires at :01, :06, :11...)
# Dmob   -> offset 2 (fires at :02, :07, :12...)
# Desmond -> offset 3 (fires at :03, :08, :13...)

for agent in gentech yoyo dmob desmond; do
  case $agent in
    gentech)  offset=0 ;; # no change
    yoyo)     offset=1 ;;
    dmob)     offset=2 ;;
    desmond)  offset=3 ;;
  esac

  cfg=~/.hermes/profiles/$agent/cron/jobs.json
  python3 -c "
import json, re, sys
with open('$cfg') as f: d = json.load(f)
for j in d.get('jobs', []):
    s = j.get('schedule', {})
    expr = s.get('expr', '')
    if expr.startswith('*/'):
        # interval-style: */5 * * * * -> offset */5 * * * * keeps the "0" base
        # just adjust the ones that all hit 0
        parts = expr.split()
        if parts[1] == '*' and parts[0].isdigit():
            old = int(parts[0])
            new = (old + $offset) % 60
            parts[0] = str(new)
            s['expr'] = ' '.join(parts)
            s['display'] = s['expr']
    elif re.match(r'^\d+\s', expr):
        parts = expr.split()
        mins = parts[0].split(',')
        new_mins = [str((int(m.strip()) + $offset) % 60) for m in mins]
        parts[0] = ','.join(new_mins)
        s['expr'] = ' '.join(parts)
        s['display'] = s['expr']
with open('$cfg','w') as f:
    json.dump(d, f, indent=2)
"
  echo "$agent: offset +$offset applied"
done
```

> **Note:** When staggering, verify the new schedules don't push jobs into invalid windows (e.g., a daily 23:50 + offset becomes 23:53, which is fine - but +5 on a 23:58 becomes 00:03 the next day, shifting the intended day).

#### Strategy B: Add a Fallback Provider

Configure a fallback provider chain so Hermes automatically rolls over when the primary 429s. This is the cleanest fix if you have keys for another provider.

**Supported fallback providers** (free tiers available):
- OpenRouter (free tier for many models)
- Google Gemini (free tier)
- GitHub Copilot (if you have Copilot subscription)

```bash
# Add fallback provider to main auth.json (profiles inherit fallback but keep their own credential pool)
hermes fallback add
# Interactive picker -> choose provider and model

# Verify chain
hermes fallback list
```

**Important:** Fallback providers are consulted when the PRIMARY provider returns rate_limit, overloaded, timeout, or connection errors. However, if your credential pool only has ONE entry for the primary provider, Hermes will:
1. Retry with backoff
2. Mark the credential exhausted
3. Then try fallback

So fallbacks work, but there's a delay. For faster failover, also use Strategy A (staggering).

#### Strategy C: Reduce Frequency of High-Fire Crons

For jobs that fire every 5 or 4 minutes (`*/5 * * * *`, `*/4 * * * *`), consider whether that frequency is actually needed:

```bash
# Change */5 -> */15 for non-critical monitoring jobs
for agent in gentech yoyo dmob desmond; do
  cfg=~/.hermes/profiles/$agent/cron/jobs.json
  python3 -c "
import json
with open('$cfg') as f: d = json.load(f)
for j in d.get('jobs', []):
    s = j.get('schedule', {})
    expr = s.get('expr', '')
    if expr.startswith('*/5'):
        s['expr'] = expr.replace('*/5', '*/15', 1)
        s['display'] = s['expr']
with open('$cfg','w') as f: json.dump(d, f, indent=2)
"
done
```

#### Strategy D: Run Ollama Locally (No Rate Limits)

If you have GPU resources, running a local Ollama server bypasses ALL cloud rate limits:

```bash
# Install Ollama
# See https://ollama.com for installation

# Pull the model
ollama pull kimi-k2.6
# or: ollama pull llama3.1:70b, etc.

# Update profiles to use local provider
for agent in gentech yoyo dmob desmond; do
  cfg=~/.hermes/profiles/$agent/config.yaml
  python3 -c "
import yaml
with open('$cfg') as f: c = yaml.safe_load(f)
# Local Ollama uses the 'ollama' provider, not 'ollama-cloud'
c['model']['provider'] = 'ollama'
c['model']['base_url'] = 'http://localhost:11434'
# model string format depends on what the local Ollama provider expects
with open('$cfg','w') as f: yaml.dump(c, f, sort_keys=False)
"
done

# Remove cloud key dependency from .env
for agent in gentech yoyo dmob desmond; do
  sed -i '/OLLAMA_API_KEY/d' ~/.hermes/profiles/$agent/.env
done
```

> **Tradeoff:** Local inference requires GPU memory (~40GB+ for 70B models). CPU inference is possible but extremely slow for large models. This is the best option if you have the hardware.

### Preventing Future 429s

After applying any mitigation, verify with the same diagnosis commands above. Also:

1. **Backup staggered schedules** - copy the modified `cron/jobs.json` to your vault so restoration keeps the offsets.
2. **Document provider limits** - in your vault, note Ollama Cloud's concurrent request limit per key so future model switches (e.g., to another provider with similar limits) are anticipated.
3. **Monitor credential pool exhaustion** - if `auth.json` shows repeated `exhausted` on `last_status`, consider a different provider or adding more keys to the pool (`hermes auth add`).

### Pitfalls Specific to Rate Limiting

- **"Too Many Concurrent Requests" is NOT billing exhaustion** - billing exhaustion shows "quota exceeded" or "insufficient credits" and is NOT retryable. 429 with "concurrent" IS retryable, but without mitigation it just repeats.
- **Staggering by offset changes the schedule permanently** - if a job MUST fire at a specific time (e.g., market open at 9:30 AM), don't apply blanket offsets to those. Offset only recurring/interval jobs.
- **Fallback provider must support the same model** - if your fallback is Gemini but the model string is `kimi-k2.6` (unknown to Gemini), fallback will fail. Use generic model names like `google/gemini-2.0-flash` or configure per-profile fallbacks.
- **Credential pools don't auto-reset** - once a key is marked `exhausted`, it stays exhausted. Use `hermes auth reset ollama-cloud` to clear after the provider's rate limit window resets.

## Pitfalls

- **Each agent needs its own Telegram bot** - you cannot reuse bot tokens across profiles
- **API keys are NOT inherited** - each profile's .env must have the provider API key (OPENCODE_GO_API_KEY, etc.) or agents crash on first message
- **TELEGRAM_ALLOWED_USERS required** - without it, all unauthorized users are denied and agents won't respond
- **TELEGRAM_HOME_CHANNEL required** - without it, cron jobs have no delivery target and won't post to any group
- **Provider consistency** - all profiles must use the same provider; mixing ollama-cloud and opencode-go causes crashes
- **Cron jobs inherit profile model** - if you change the profile model, all cron jobs switch too
- **Cron job overrides persist** - individual cron jobs with explicit `model` or `provider` fields do NOT follow profile model changes and must be updated manually (see step H above)
- **SOUL.md defines routing rules** - agents should only respond in their assigned Telegram group
- **Gateway install before start** - run `hermes -p <name> gateway install` before `gateway start` (one-time systemd setup)
- **Use stop+start, not restart** - `gateway restart` can cause crash loops; use `gateway stop` then `gateway start` for reliability
- **Obsidian vault sync** - all agents share one vault; coordinate writes to avoid conflicts
- **Profile auth.json must contain provider credentials** - OAuth tokens or API keys must be copied into each profile's `auth.json`; credentials are NOT inherited from the global `~/.hermes/auth.json`. Missing credentials cause silent gateway failures (e.g., "Hermes is not logged into Nous Portal").
- **YAML corruption in config.yaml** - if a profile's config.yaml has syntax errors (e.g., "mapping values are not allowed here"), the gateway will fail to start. Use `python3 -c "import yaml; yaml.safe_load(open('path'))"` to validate, then fix the structural issue (often malformed `auxiliary:` section). Restore from backup if needed.

## Verification

```bash
# Check all profiles
hermes profile list

# Verify each agent's config
for agent in *; do
  model=$(grep -A2 "^model:" ~/.hermes/profiles/$agent/config.yaml | grep "default:" | awk '{print $2}')
  provider=$(grep -A3 "^model:" ~/.hermes/profiles/$agent/config.yaml | grep "provider:" | awk '{print $2}')
  echo "$agent: $model via $provider"
done

# Check all env vars
for agent in *; do
  echo "=== $agent ==="
  grep -E "TELEGRAM|OPENCODE|ELEVENLABS|OBSIDIAN" ~/.hermes/profiles/$agent/.env | sed 's/=.*/=***/'
done

# Count cron jobs
for agent in *; do
  count=$(cat ~/.hermes/profiles/$agent/cron/jobs.json 2>/dev/null | python3 -c "import sys,json; print(len(json.load(sys.stdin).get('jobs',[])))" 2>/dev/null || echo 0)
  echo "$agent: $count cron jobs"
done

# Check for cron jobs with explicit model/provider overrides (should be zero after step H)
for agent in *; do
  overrides=$(cat ~/.hermes/profiles/$agent/cron/jobs.json 2>/dev/null | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(sum(1 for j in d.get('jobs',[]) if j.get('model') or j.get('provider')))
" 2>/dev/null || echo '?')
  echo "$agent: $overrides cron overrides remaining"
done

# Verify gateways running
for agent in *; do
  status=$(hermes -p $agent gateway status 2>&1 | grep "Active:" | awk '{print $2, $3}')
  echo "$agent: $status"
done
```
