#!/usr/bin/env python3
"""
Validate and repair Hermes profile config.yaml files.

Detects common corruption patterns (malformed YAML, broken auxiliary sections)
and attempts repairs. Creates backups before modifying.

Usage:
  python scripts/validate_profiles.py --check          # Just report status
  python scripts/validate_profiles.py --repair        # Fix what we can
  python scripts/validate_profiles.py --profile yoyo  # Single profile
"""

import argparse
import shutil
import sys
import yaml
from pathlib import Path

HERMES_HOME = Path.home() / ".hermes"
PROFILES = ["desmond", "dmob", "gentech", "yoyo"]

def validate_yaml(path: Path) -> tuple[bool, str | None]:
    """Check if YAML file parses. Return (ok, error_message)."""
    try:
        with open(path) as f:
            yaml.safe_load(f)
        return True, None
    except yaml.YAMLError as e:
        return False, str(e)

def repair_auxiliary_section(content: str) -> str:
    """Fix common corruption: malformed auxiliary: block with misplaced 'default:' key."""
    lines = content.splitlines(keepends=True)
    # Find 'auxiliary:' line
    for i, line in enumerate(lines):
        if line.strip() == "auxiliary:":
            # The next non-empty line should be an indented key (e.g., "  vision:")
            # If we see "  default:" here instead, the section is corrupted
            j = i + 1
            while j < len(lines) and lines[j].strip() == "":
                j += 1
            if j < len(lines):
                next_line = lines[j]
                # Check if it's misplaced: starts with 2 spaces then 'default:'
                if next_line.startswith("  ") and next_line.strip().startswith("default:"):
                    # This line should not be here — remove it
                    lines[j] = ""
                    # Now rebuild proper structure: insert vision block after 'auxiliary:'
                    vision_block = [
                        "  vision:\n",
                        "    provider: auto\n",
                        "    model: ''\n",
                        "    base_url: ''\n",
                        "    api_key: ''\n",
                        "    timeout: 120\n",
                        "    extra_body: {}\n",
                        "    download_timeout: 30\n",
                    ]
                    lines = lines[: i + 1] + vision_block + lines[j + 1 :]
                    return "".join(lines)
    return content  # no fix needed

def repair_config(profile: str, dry_run: bool = False) -> tuple[bool, str]:
    """Attempt to repair a profile's config.yaml. Return (repaired, message)."""
    cfg_path = HERMES_HOME / "profiles" / profile / "config.yaml"
    if not cfg_path.exists():
        return False, f"config.yaml does not exist"

    backup_path = cfg_path.with_suffix(".yaml.bak")
    shutil.copy2(cfg_path, backup_path)

    with open(cfg_path) as f:
        original = f.read()

    ok, err = validate_yaml(cfg_path)
    if ok:
        return False, "already valid"

    # Try repair
    repaired_content = repair_auxiliary_section(original)

    if repaired_content == original:
        return False, f"cannot auto-repair: {err}"

    if not dry_run:
        with open(cfg_path, "w") as f:
            f.write(repaired_content)
        # Re-validate
        ok2, err2 = validate_yaml(cfg_path)
        if ok2:
            return True, f"repaired successfully (backup at {backup_path})"
        else:
            # Restore backup on failure
            shutil.copy2(backup_path, cfg_path)
            return False, f"repair failed: {err2}"
    else:
        return True, f"would repair (dry-run) — backup present at {backup_path}"

def main():
    parser = argparse.ArgumentParser(description="Validate/repair Hermes profile configs")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--profile", help="Single profile to check")
    group.add_argument("--all", action="store_true", help="Check all profiles")
    parser.add_argument("--repair", action="store_true", help="Attempt repairs")
    parser.add_argument("--dry-run", action="store_true", help="Preview repairs without writing")
    args = parser.parse_args()

    profiles = [args.profile] if args.profile else PROFILES
    action = "VALIDATE" if not args.repair else ("REPAIR (dry-run)" if args.dry_run else "REPAIR")

    overall_ok = True
    for profile in profiles:
        print(f"\n[{profile.upper()}]")
        ok, msg = validate_yaml(HERMES_HOME / "profiles" / profile / "config.yaml")
        if ok:
            print(f"  ✓ {msg}")
        else:
            print(f"  ✗ invalid: {msg}")
            if args.repair:
                repaired, repair_msg = repair_config(profile, dry_run=args.dry_run)
                if repaired:
                    print(f"  ✓ {repair_msg}")
                else:
                    print(f"  ✗ {repair_msg}")
                    overall_ok = False

    print(f"\n{'='*50}")
    if overall_ok:
        print("All profiles valid" if not args.repair else "Repair pass complete")
    else:
        print("Some profiles could not be repaired automatically — manual intervention required.")
        sys.exit(1)

if __name__ == "__main__":
    main()
