#!/usr/bin/env python3
"""
Fix cron job model/provider overrides to match the profile's target model.

Usage:
  python scripts/fix_cron_overrides.py --profile gentech --model stepfun/step-3.5-flash --provider nous
  python scripts/fix_cron_overrides.py --all --model stepfun/step-3.5-flash --provider nous

This scans ~/.hermes/profiles/<profile>/cron/jobs.json for jobs with explicit
`model` or `provider` fields and updates them to the target values.
"""

import argparse
import json
import os
import sys
from pathlib import Path

HERMES_HOME = Path.home() / ".hermes"
PROFILES = ["desmond", "dmob", "gentech", "yoyo"]

def profile_path(profile: str) -> Path:
    return HERMES_HOME / "profiles" / profile

def load_cron(profile: str) -> dict:
    cron_file = profile_path(profile) / "cron" / "jobs.json"
    if not cron_file.exists():
        print(f"[{profile}] No cron/jobs.json found")
        return None
    with open(cron_file) as f:
        return json.load(f)

def save_cron(profile: str, data: dict) -> None:
    cron_file = profile_path(profile) / "cron" / "jobs.json"
    with open(cron_file, "w") as f:
        json.dump(data, f, indent=2)
    print(f"[{profile}] Saved updated jobs.json")

def fix_overrides(profile: str, target_model: str, target_provider: str, dry_run: bool = False) -> int:
    data = load_cron(profile)
    if data is None:
        return 0

    jobs = data.get("jobs", [])
    updated = 0
    for job in jobs:
        changed = False
        old_model = job.get("model")
        old_provider = job.get("provider")

        if old_model and old_model != target_model:
            print(f"  Job '{job.get('name','?')}': model {old_model} -> {target_model}")
            job["model"] = target_model
            changed = True
            updated += 1
        if old_provider and old_provider != target_provider:
            print(f"  Job '{job.get('name','?')}': provider {old_provider} -> {target_provider}")
            job["provider"] = target_provider
            changed = True
            # updated already counted above if both changed

        if changed and dry_run:
            # revert for dry-run preview
            job["model"] = old_model
            job["provider"] = old_provider
            updated -= 1 if old_model else 0  # only decrement if we actually counted

    if updated and not dry_run:
        save_cron(profile, data)
    elif updated == 0:
        print(f"  [{profile}] No overrides need updating")
    else:
        print(f"  [{profile}] Would update {updated} jobs (dry-run)")

    return updated

def main():
    parser = argparse.ArgumentParser(description="Fix cron job model/provider overrides across profiles")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--profile", help="Single profile to fix")
    group.add_argument("--all", action="store_true", help="Fix all GenTech profiles")
    parser.add_argument("--model", required=True, help="Target model (e.g., stepfun/step-3.5-flash)")
    parser.add_argument("--provider", required=True, help="Target provider (e.g., nous)")
    parser.add_argument("--dry-run", action="store_true", help="Preview changes without writing")
    args = parser.parse_args()

    profiles = [args.profile] if args.profile else PROFILES
    total = 0

    for profile in profiles:
        total += fix_overrides(profile, args.model, args.provider, args.dry_run)

    print(f"\nTotal jobs {'would be ' if args.dry_run else ''}updated: {total}")

if __name__ == "__main__":
    main()
