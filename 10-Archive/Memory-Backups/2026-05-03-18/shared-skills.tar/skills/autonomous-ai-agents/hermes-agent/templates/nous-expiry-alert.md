🚨 *Nous Auth Expiry Reminder* 🚨

The Nous Research agent key expires in 1 hour (at `10:41 UTC`).

Re-authenticate now to avoid interruption:
```
hermes auth add nous --type oauth
```

After re-auth, restart the gateway:
```
hermes gateway restart
```

This affects all 4 Telegram agents:
- Gentech (CEO)
- YoYo (Strategies)
- DMOB (Labs)
- Desmond (Creative)

Check status with: `hermes status`

---

*This alert is scheduled via `hermes cron`. Adjust expiry time by checking `hermes status` or inspecting `~/.hermes/auth.json` → `agent_key_expires_at`.*