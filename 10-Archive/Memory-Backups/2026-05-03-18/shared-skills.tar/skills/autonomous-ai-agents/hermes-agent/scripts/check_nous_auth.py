#!/usr/bin/env python3
"""
Check Nous Portal auth age and warn if expiry is imminent.
Usage: python check_nous_auth.py [--warn-hours N] [--telegram CHAT_ID]
"""
import json, os, sys, argparse, subprocess, time
from datetime import datetime, timezone

def load_auth():
    path = os.path.expanduser('~/.hermes/auth.json')
    with open(path) as f:
        data = json.load(f)
    return data['providers']['nous']

def parse_iso(s):
    # Handle both 'Z' and '+00:00' formats
    return datetime.fromisoformat(s.replace('Z', '+00:00'))

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--warn-hours', type=float, default=1.0,
                   help='Warn if agent_key expires within this many hours')
    p.add_argument('--telegram', help='Telegram chat ID to send alert to')
    p.add_argument('--gateway-restart', action='store_true',
                   help='Suggest gateway restart if re-auth needed')
    args = p.parse_args()

    auth = load_auth()
    key_exp = parse_iso(auth['agent_key_expires_at'])
    now = datetime.now(timezone.utc)
    remaining = key_exp - now
    hours = remaining.total_seconds() / 3600

    print(f"Agent key expires at: {key_exp.isoformat()}")
    print(f"Time remaining: {remaining}")

    if hours <= 0:
        print("ERROR: Agent key is expired. Hermes API calls will fail.")
        alert = "❌ *Nous Auth EXPIRED* — Re-authenticate immediately:\n`hermes auth add nous --type oauth`"
        if args.gateway_restart:
            alert += "\nThen restart: `hermes gateway restart`"
        if args.telegram:
            send_telegram(args.telegram, alert)
        return 2
    elif hours <= args.warn_hours:
        print(f"WARNING: Expiring within {args.warn_hours}h.")
        alert = (f"🚨 *Nous Auth Expiry* — Re-authenticate in ~{hours:.1f}h "
                 f"(at {key_exp.strftime('%H:%M UTC')}).\n"
                 f"`hermes auth add nous --type oauth`")
        if args.gateway_restart:
            alert += "\nAfter re-auth: `hermes gateway restart`"
        if args.telegram:
            send_telegram(args.telegram, alert)
        return 1
    else:
        print(f"OK: {hours:.1f}h remaining.")
        return 0

def send_telegram(chat_id, text):
    # Use Hermes gateway to send; fallback to curl if needed
    # Hermes can send via messaging tool, but simplest is using the gateway delivery
    # For a standalone script, call `hermes` in a subprocess with deliver flag
    cmd = ['hermes', 'chat', '-q', text, '--deliver', f'telegram:{chat_id}']
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        print(f"Telegram send failed: {r.stderr}", file=sys.stderr)

if __name__ == '__main__':
    sys.exit(main())
