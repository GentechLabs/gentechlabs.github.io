#!/bin/bash
# Check Nous Portal auth health and optionally restart gateway if needed.
# Usage: ./scripts/check_nous_auth.sh [--autorestart]
# Requires: jq

set -e

AUTH_FILE="${HOME}/.hermes/auth.json"
AUTORESTART=0

if [[ "$1" == "--autorestart" ]]; then
  AUTORESTART=1
fi

if [[ ! -f "$AUTH_FILE" ]]; then
  echo "ERROR: auth.json not found at $AUTH_FILE"
  exit 2
fi

# Extract Nous fields
N_NOW=$(date -u +%s)
N_EXP=$(jq -r '.providers.nous.expires_at // empty' "$AUTH_FILE" 2>/dev/null || echo "")
N_KEY_EXP=$(jq -r '.providers.nous.agent_key_expires_at // empty' "$AUTH_FILE" 2>/dev/null || echo "")
N_HAS_REFRESH=$(jq -r '.providers.nous.refresh_token // empty' "$AUTH_FILE" 2>/dev/null || echo "")

if [[ -z "$N_EXP" || -z "$N_KEY_EXP" ]]; then
  echo "ERROR: Nous auth fields missing in $AUTH_FILE"
  exit 3
fi

# Convert ISO8601 to epoch
N_EXP_EPOCH=$(date -d "$N_EXP" +%s 2>/dev/null || date -j -f "%Y-%m-%dT%H:%M:%S%z" "$N_EXP" +%s 2>/dev/null || echo 0)
N_KEY_EXP_EPOCH=$(date -d "$N_KEY_EXP" +%s 2>/dev/null || date -j -f "%Y-%m-%dT%H:%M:%S%z" "$N_KEY_EXP" +%s 2>/dev/null || echo 0)

N_TTL=$((N_EXP_EPOCH - N_NOW))
N_KEY_TTL=$((N_KEY_EXP_EPOCH - N_NOW))

echo "Nous Portal auth status:"
echo "─────────────────────────"
echo "  access_token  : expires in ${N_TTL}s  ($(date -d "@$N_EXP_EPOCH" -u +%H:%M:%S UTC))"
echo "  agent_key     : expires in ${N_KEY_TTL}s ($(date -d "@$N_KEY_EXP_EPOCH" -u +%H:%M:%S UTC))"
echo "  refresh_token : ${N_HAS_REFRESH:+(present)}"

# Heuristics
if [[ $N_KEY_TTL -lt 3600 ]]; then
  echo ""
  echo "⚠  agent_key expires in < 1h. Consider re-authorizing:"
  echo "   hermes auth add nous --type oauth"
  if [[ $AUTORESTART -eq 1 ]]; then
    echo "   (--autorestart set, NOT auto-restarting gateway)"
  fi
  EXIT_CODE=1
elif [[ $N_TTL -lt 300 ]]; then
  echo ""
  echo "⚠  access_token expires soon (< 5m). Auto-refresh on next use should work."
  EXIT_CODE=0
else
  echo ""
  echo "✓  Status nominal."
  EXIT_CODE=0
fi

if [[ $AUTORESTART -eq 1 ]]; then
  # Check if gateway is running and needs restart to propagate new agent_key
  if systemctl --user is-active --quiet hermes-gateway 2>/dev/null; then
    echo "   Gateway active — restarting to propagate any new credentials..."
    systemctl --user restart hermes-gateway
    echo "   ✓ Gateway restarted."
  else
    echo "   Gateway not running via systemd; no restart needed."
  fi
fi

exit $EXIT_CODE
