# Nous Portal Auth Structure & Expiry Behavior

## Auth File Location
`~/.hermes/auth.json` — stored under `providers.nous`

## Credential Fields

```json
{
  "access_token": "eyJ...",              // Short-lived OAuth token (≈15 min)
  "refresh_token": "rt_...",             // Long-lived refresh token
  "access_token_expires_at": "2026-...", // When access_token expires
  "agent_key": "sk-nous-...",            // Actual inference API key
  "agent_key_expires_at": "2026-...",    // When inference actually fails (≈24h)
  "agent_key_obtained_at": "...",
  "expires_in": 900,                     // Access token TTL in seconds
  "obtained_at": "...",
  "client_id": "hermes-cli",
  "portal_base_url": "https://portal.nousresearch.com",
  "inference_base_url": "https://inference-api.nousresearch.com/v1"
}
```

## Key Insight: Two-Token System

- `access_token` (OAuth) expires quickly (~15 min). Auto-refreshes using `refresh_token` on next API call.
- `agent_key` (inference credential) is minted from the access token and is the actual model-usage key. Valid for ~24 hours.
- **The `access_token_expires_at` timestamp does NOT update on auto-refresh** — it's a fixed 900-second window from `obtained_at`. The `agent_key_expires_at` is what matters.
- After a successful API call, the `agent_key` may be refreshed and its `agent_key_expires_at` extended to ~24 hours from that moment.

## Monitoring Expiry

```bash
# Check status
hermes status
# Look for: "Access exp:" and "Key exp:"

# Inspect raw auth file
cat ~/.hermes/auth.json | jq '.providers.nous'
```

### Warning Signs
- `agent_key_expires_at` within 1 hour → schedule re-auth reminder
- API 401 errors → token likely expired; run `hermes auth add nous --type oauth`

## Re-auth Workflow

```bash
# Step 1: Initiate OAuth (opens browser; may hit Vercel checkpoint)
hermes auth add nous --type oauth

# If Cloudflare checkpoint appears, complete in browser manually,
# then return to terminal and wait for success message.

# Step 2: Restart gateway so all profiles reload
hermes gateway restart
```

## OAuth Security Checkpoint

The `https://portal.nousresearch.com/oauth/device/code` endpoint is behind Vercel's anti-DDoS page ("We're verifying your browser"). If you see an HTML checkpoint page instead of JSON, you must:
1. Complete the browser challenge manually
2. Approve the Hermes CLI OAuth consent
3. Return to the terminal; the CLI will poll and complete automatically

## Auto-Refresh Behavior

Hermes automatically uses the `refresh_token` to obtain a new `access_token` + `agent_key` when an API call detects expiry. No manual intervention needed **until**:
- The `refresh_token` itself expires (rare; lasts weeks)
- The `agent_key` expiry window closes without any API call to trigger refresh
- Manual re-auth requested to extend proactively

## Cron Reminder Template

```bash
hermes cron create "$(date -d 'tomorrow 09:41 UTC' +%Y-%m-%dT09:41:00Z)" \
  "🚨 Nous Auth Expiry Reminder

The Nous Research agent key expires in 1 hour (at 10:41 UTC).

Re-authenticate now to avoid interruption:
  hermes auth add nous --type oauth

After re-auth, restart: hermes gateway restart

Affects: Gentech, YoYo, DMOB, Desmond Telegram agents." \
  --name "nous-reauth-reminder" \
  --deliver telegram:-100386354028
```

Adjust the time to `agent_key_expires_at minus 1 hour`.