# Nous Connectivity Triage (derived from session 2026-05-03)

When a user reports "Hermes can't reach Nous Research" or model calls fail, run this sequence:

## Step 1: Quick status check
```bash
hermes status
```
Look for:
- `Nous Portal   ✓ logged in` — confirms auth exists
- `Access exp:` and `Key exp:` timestamps — is `agent_key_expires_at` in the past?
- `Provider: Nous Portal` — correct provider set
- Any 401/authentication errors in recent logs: `grep -i "401\|auth" ~/.hermes/logs/gateway.log | tail -20`

## Step 2: Verify auth file
```bash
cat ~/.hermes/auth.json | python3 -m json.tool | grep -A5 '"nous"'
```
Check:
- `agent_key` present (starts with `sk-nous-`)
- `agent_key_expires_at` is future-dated
- `refresh_token` exists

If `agent_key` missing or expired → re-auth required.

## Step 3: Run diagnostics
```bash
hermes doctor
```
Fix common issues automatically:
```bash
hermes doctor --fix
```
Watch for:
- Broken symlinks (fixed automatically)
- Missing API keys for other providers (non-fatal)
- Out-of-date installation

## Step 4: Test with single-shot query
```bash
hermes chat -q "Hello test" --verbose
```
Success criteria: API call completes without 401/403 errors and assistant returns text.

## Step 5: If still failing
- Re-authenticate: `hermes auth add nous --type oauth` (follow browser flow)
- Restart gateway: `hermes gateway restart` (or relaunch CLI)
- Update Hermes: `hermes update`

## Common root causes (in order of frequency)
1. **Agent key expired** (`agent_key_expires_at` past) → re-auth
2. **Access token expired** but auto-refresh failed → re-auth (refresh_token invalid/absent)
3. **Gateway not restarted** after auth change → restart gateway
4. **Broken hermes symlink** → `hermes doctor --fix`
5. **Outdated Hermes** (older auth flow) → `hermes update`
6. **Network/Vercel checkpoint** on portal.nousresearch.com → complete browser challenge manually

## Notes
- The `access_token_expires_at` shows a fixed 15-minute window from `obtained_at` and does NOT update on auto-refresh. Ignore it; focus on `agent_key_expires_at`.
- Auto-refresh happens transparently on the next API call after access token expiry.
- After re-auth, **gateway restart is required** for all profiles to pick up new tokens.
