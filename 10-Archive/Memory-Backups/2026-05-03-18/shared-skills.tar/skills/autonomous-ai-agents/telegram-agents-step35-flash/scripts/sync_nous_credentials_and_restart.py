#!/usr/bin/env python3
"""Sync fresh Nous credentials from global auth.json to all GenTech agent profiles and restart gateways.

Use this after completing a fresh device OAuth (via `hermes model` or device flow snippet)
when profiles still show expired tokens. The proactive refresh cron job only updates profiles
on its next schedule tick; this script forces immediate sync + restart.

Profiles: gentech, desmond, dmob, yoyo
"""

import json
import os
import subprocess
import sys
import time

HOME = os.path.expanduser('~')
AUTH_PATH = os.path.join(HOME, '.hermes', 'auth.json')
PROFILES = ['gentech', 'desmond', 'dmob', 'yoyo']


def load_global_auth():
    with open(AUTH_PATH) as f:
        return json.load(f)


def sync_credentials():
    """Copy fresh Nous credential_pool entry to each profile's auth.json."""
    auth = load_global_auth()
    nous_global = None
    for cred in auth.get('credential_pool', {}).get('nous', []):
        nous_global = cred
        break
    if not nous_global:
        print("❌ No Nous credentials found in global credential_pool")
        return False

    print(f"✓ Found global Nous credential (expires: {nous_global.get('expires_at')})")
    
    for prof in PROFILES:
        prof_path = os.path.join(HOME, '.hermes', 'profiles', prof, 'auth.json')
        if not os.path.exists(prof_path):
            print(f"⚠ Profile {prof} auth.json not found, skipping")
            continue
        with open(prof_path) as f:
            prof_auth = json.load(f)
        # Ensure credential_pool exists
        if 'credential_pool' not in prof_auth:
            prof_auth['credential_pool'] = {}
        prof_auth['credential_pool']['nous'] = [nous_global.copy()]
        # Also update providers.nous section (used by some gateway paths)
        if 'providers' not in prof_auth:
            prof_auth['providers'] = {}
        prof_auth['providers']['nous'] = {
            "auth_type": "oauth",
            "portal_base_url": "https://portal.nousresearch.com",
            "inference_base_url": "https://inference-api.nousresearch.com/v1",
            "agent_key": nous_global.get('agent_key'),
            "agent_key_id": nous_global.get('agent_key_id'),
            "access_token": nous_global.get('access_token'),
            "refresh_token": nous_global.get('refresh_token'),
            "expires_at": nous_global.get('expires_at'),
            "token_type": "Bearer",
            "scope": "inference:mint_agent_key"
        }
        with open(prof_path, 'w') as f:
            json.dump(prof_auth, f, indent=2)
        print(f"✓ Synced to {prof}")
    return True


def restart_gateways():
    """Restart all 4 agent gateways to load fresh credentials."""
    print("\nRestarting gateways...")
    for prof in PROFILES:
        print(f"\n--- {prof} ---")
        stop = subprocess.run(['hermes', '-p', prof, 'gateway', 'stop'],
                             capture_output=True, text=True, timeout=30)
        print(f"Stop: {stop.stdout.strip() or stop.stderr.strip()}")
        start = subprocess.run(['hermes', '-p', prof, 'gateway', 'start'],
                              capture_output=True, text=True, timeout=30)
        print(f"Start: {start.stdout.strip() or start.stderr.strip()}")
        status = subprocess.run(['systemctl', '--user', 'status',
                                f'hermes-gateway-{prof}.service', '--no-pager'],
                               capture_output=True, text=True)
        active = [l for l in status.stdout.split('\n') if 'Active:' in l]
        if active:
            print(f"Status: {active[0].strip()}")
        else:
            print(f"Status: unable to determine (exit {status.returncode})")


def verify_tokens():
    """Run the built-in token expiry checker and report."""
    print("\nVerifying token status...")
    script = os.path.join(HOME, '.hermes', 'skills',
                          'autonomous-ai-agents', 'telegram-agents-step35-flash',
                          'scripts', 'check_nous_token_expiry.py')
    result = subprocess.run(['python3', script], capture_output=True, text=True)
    print(result.stdout)
    return result.returncode == 0


def main():
    print("=== GenTech Nous Credential Sync + Gateway Restart ===\n")
    
    if not os.path.exists(AUTH_PATH):
        print(f"❌ Global auth not found at {AUTH_PATH}")
        sys.exit(1)
    
    print("Step 1: Syncing credentials to profiles...")
    if not sync_credentials():
        print("\n✗ Sync failed — aborting")
        sys.exit(1)
    
    print("\nStep 2: Restarting all gateways...")
    restart_gateways()
    
    print("\nStep 3: Waiting 5s for gateways to settle...")
    time.sleep(5)
    
    if verify_tokens():
        print("\n✅ All agents have valid tokens and are running.")
    else:
        print("\n⚠ Some agents still show expired tokens — they may need a manual re-auth via `hermes model`")
        sys.exit(1)


if __name__ == '__main__':
    main()
