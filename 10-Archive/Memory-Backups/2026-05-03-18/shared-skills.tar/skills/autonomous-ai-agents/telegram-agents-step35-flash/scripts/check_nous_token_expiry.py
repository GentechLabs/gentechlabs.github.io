#!/usr/bin/env python3
"""
Check Nous OAuth token expiry across all GenTech agent profiles.

Usage:
  python3 check_nous_token_expiry.py      # show status
  python3 check_nous_token_expiry.py --reset  # stop gateways and re-auth (requires interactive)
"""

import json
import os
import sys
import datetime
import subprocess

HOME = os.path.expanduser("~/.hermes/profiles")
PROFILES = ["gentech", "desmond", "dmob", "yoyo"]


def load_profile_auth(profile):
    auth_path = os.path.join(HOME, profile, "auth.json")
    with open(auth_path) as f:
        return json.load(f)


def get_nous_expiry(auth):
    pool = auth.get("credential_pool", {}).get("nous", [])
    if not pool:
        return None
    cred = pool[0]
    exp_str = cred.get("expires_at")
    return exp_str


def parse_iso(exp_str):
    if not exp_str:
        return None
    # Handle Z suffix
    return datetime.datetime.fromisoformat(exp_str.replace("Z", "+00:00"))


def main():
    now = datetime.datetime.now(datetime.timezone.utc)
    any_expired = False

    print("=== GenTech Nous Token Expiry Check ===")
    for prof in PROFILES:
        auth = load_profile_auth(prof)
        exp_str = get_nous_expiry(auth)
        if not exp_str:
            print(f"{prof}: ⚠️  No Nous credential found")
            continue

        exp_dt = parse_iso(exp_str)
        if exp_dt is None:
            print(f"{prof}: ❓ Cannot parse expiry: {exp_str}")
            continue

        remaining = (exp_dt - now).total_seconds()
        if remaining > 0:
            mins = int(remaining // 60)
            print(f"{prof}: ✅ Valid — expires in {mins}m ({exp_str})")
        else:
            print(f"{prof}: ❌ EXPIRED — {abs(int(remaining//60))}m ago ({exp_str})")
            any_expired = True

    print()
    if any_expired:
        print("ACTION REQUIRED: At least one profile has an expired Nous token.")
        print("Run: hermes model   (to re-authenticate interactively)")
        print("Then stop & restart all gateways to sync new credentials.")
        return 1
    else:
        print("All tokens are valid. Gateways are healthy.")
        return 0


if __name__ == "__main__":
    sys.exit(main())
