#!/usr/bin/env python3
"""Check gateway_notify_interval across all GenTech Telegram agent profiles.

Usage:
  python3 check_gateway_interval.py        # print current values
  python3 check_gateway_interval.py --reset  # reset to 180 and restart gateways

Exit codes:
  0 — all profiles at expected value (default 180 unless overridden)
  1 — mismatch found or reset failed
"""

import yaml
import os
import subprocess
import sys

HOME = os.path.expanduser('~/.hermes/profiles')
PROFILES = ['gentech', 'desmond', 'dmob', 'yoyo']
DEFAULT_INTERVAL = 180

def read_interval(profile):
    cfg = yaml.safe_load(open(os.path.join(HOME, profile, 'config.yaml')))
    return cfg['agent'].get('gateway_notify_interval', DEFAULT_INTERVAL)

def print_values():
    print('=== gateway_notify_interval per profile ===')
    for prof in PROFILES:
        val = read_interval(prof)
        print(f'{prof}: {val} seconds')

def all_match(expected):
    return all(read_interval(p) == expected for p in PROFILES)

def reset_to_default():
    print('Resetting gateway_notify_interval to 180 and restarting gateways...')
    for prof in PROFILES:
        cfg_path = os.path.join(HOME, prof, 'config.yaml')
        cfg = yaml.safe_load(open(cfg_path))
        cfg['agent']['gateway_notify_interval'] = DEFAULT_INTERVAL
        yaml.dump(cfg, open(cfg_path, 'w'), sort_keys=False)
        print(f'  {prof}: config updated')
    # Restart gateways
    for prof in PROFILES:
        subprocess.run(['hermes', '-p', prof, 'gateway', 'restart'], check=True)
        print(f'  {prof}: gateway restarted')
    print('Done.')

def verify_logs():
    print('=== Recent gateway log excerpts ===')
    for prof in PROFILES:
        log_path = os.path.join(HOME, prof, 'logs', 'gateway.log')
        lines = open(log_path).readlines()[-3:]
        print(f'{prof}:')
        for line in lines:
            print(f'  {line.strip()}')

if __name__ == '__main__':
    print_values()
    if '--reset' in sys.argv:
        if all_match(DEFAULT_INTERVAL):
            print('Already at default (180). No reset needed.')
            sys.exit(0)
        try:
            reset_to_default()
            verify_logs()
            sys.exit(0 if all_match(DEFAULT_INTERVAL) else 1)
        except Exception as e:
            print(f'Reset failed: {e}', file=sys.stderr)
            sys.exit(1)
    else:
        ok = all_match(DEFAULT_INTERVAL)
        print(f'\nStatus: {"OK" if ok else "MISMATCH"} (expected {DEFAULT_INTERVAL})')
        sys.exit(0 if ok else 1)
