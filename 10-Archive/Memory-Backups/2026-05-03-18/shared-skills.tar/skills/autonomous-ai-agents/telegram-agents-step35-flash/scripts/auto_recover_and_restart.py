#!/usr/bin/env python3
"""
Automated recovery for expired Nous OAuth tokens across all GenTech Telegram agent profiles.

This script performs the complete recovery cycle:
1. Detects expired tokens across all profiles
2. Generates a fresh OAuth device code (non-interactive)
3. Prompts user to approve in browser (prints URL + code)
4. Waits for user signal that approval is complete
5. Syncs fresh global Nous credentials to all agent profiles
6. Restarts all gateway services
7. Verifies all tokens are valid and Telegram connected

Usage:
  python3 auto_recover_and_restart.py

Returns exit code 0 on full success, 1 if any step fails.
"""

import json
import os
import sys
import time
import datetime
import subprocess
import urllib.request
import urllib.parse

HOME = os.path.expanduser('~/.hermes')
PROFILES = ['gentech', 'desmond', 'dmob', 'yoyo']
AUTH_FILE = f'{HOME}/auth.json'


def load_global_auth():
    with open(AUTH_FILE) as f:
        return json.load(f)


def check_token_expiry():
    """Check all profiles, return dict of statuses."""
    now = datetime.datetime.now(datetime.timezone.utc)
    status = {}
    for prof in PROFILES:
        path = f'{HOME}/profiles/{prof}/auth.json'
        with open(path) as f:
            auth = json.load(f)
        cred = auth.get('credential_pool', {}).get('nous', [{}])[0]
        exp_str = cred.get('expires_at', 'unknown')
        if exp_str == 'unknown':
            status[prof] = {'valid': False, 'reason': 'no_expiry_field'}
        else:
            exp_dt = datetime.datetime.fromisoformat(exp_str.replace('Z', '+00:00'))
            delta = (exp_dt - now).total_seconds()
            status[prof] = {
                'valid': delta > 0,
                'expires_at': exp_str,
                'seconds_remaining': delta
            }
    return status


def generate_device_code():
    """Generate a fresh OAuth device code from Nous Portal."""
    portal = "https://portal.nousresearch.com"
    data = urllib.parse.urlencode({
        "client_id": "hermes-cli",
        "scope": "inference:mint_agent_key"
    }).encode()
    req = urllib.request.Request(
        f"{portal}/api/oauth/device/code",
        data=data,
        headers={"Content-Type": "application/x-www-form-urlencoded"}
    )
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())


def sync_credentials_to_profiles(nous_cred):
    """Overwrite each profile'sNous credential pool with the fresh one."""
    for prof in PROFILES:
        path = f'{HOME}/profiles/{prof}/auth.json'
        with open(path) as f:
            auth = json.load(f)
        auth['credential_pool']['nous'] = nous_cred
        with open(path, 'w') as f:
            json.dump(auth, f, indent=2)
        print(f"  ✓ Synced to {prof}")


def restart_gateways():
    """Stop then start all gateways."""
    for prof in PROFILES:
        print(f"\n--- Restarting {prof} ---")
        subprocess.run(['hermes', '-p', prof, 'gateway', 'stop'], check=True)
        subprocess.run(['hermes', '-p', prof, 'gateway', 'start'], check=True)
        time.sleep(1)  # brief stagger
    print("\nAll gateways restarted.")


def verify_all_healthy():
    """Run the check_nous_token_expiry.py script and return True if all valid."""
    script = f'{HOME}/skills/autonomous-ai-agents/telegram-agents-step35-flash/scripts/check_nous_token_expiry.py'
    result = subprocess.run(['python3', script], capture_output=True, text=True)
    print(result.stdout)
    return result.returncode == 0


def main():
    print("=== GenTech Nous Token Auto-Recovery ===\n")
    
    # Phase 1: Check current state
    print("Phase 1 — Checking token expiry status...")
    status = check_token_expiry()
    all_valid = all(s['valid'] for s in status.values() if 'valid' in s)
    if all_valid:
        print("All tokens already valid. Nothing to do.")
        return 0
    
    expired = [p for p, s in status.items() if not s['valid']]
    print(f"Profiles with expired/invalid tokens: {', '.join(expired)}")
    
    # Phase 2: Generate OAuth device code
    print("\nPhase 2 — Generating OAuth device code...")
    device = generate_device_code()
    url = device['verification_uri_complete']
    code = device['user_code']
    print(f"\nACTION REQUIRED:")
    print(f"  1. Open: {url}")
    print(f"  2. Enter code: {code}")
    print(f"  3. Approve access\n")
    
    # Phase 3: Wait for user approval
    input("Press ENTER after you've approved in the browser...")
    
    # Phase 4: Verify global auth is now fresh
    print("\nPhase 4 — Verifying global Nous credentials...")
    with open(AUTH_FILE) as f:
        global_auth = json.load(f)
    nous_cred = global_auth.get('credential_pool', {}).get('nous')
    if not nous_cred:
        print("ERROR: No Nous credentials found in global auth.json after OAuth.")
        return 1
    print(f"  ✓ Global Nous credential pool present (expires: {nous_cred[0].get('expires_at')})")
    
    # Phase 5: Sync to all profiles
    print("\nPhase 5 — Syncing credentials to all agent profiles...")
    sync_credentials_to_profiles(nous_cred)
    
    # Phase 6: Restart gateways
    print("\nPhase 6 — Restarting all gateways...")
    restart_gateways()
    
    # Phase 7: Verify
    print("\nPhase 7 — Verification...")
    time.sleep(3)  # give gateways a moment to fully start
    if verify_all_healthy():
        print("\n✅ All agents recovered and healthy.")
        return 0
    else:
        print("\n❌ Some profiles still have issues. Check logs.")
        return 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n\nRecovery cancelled by user.")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
