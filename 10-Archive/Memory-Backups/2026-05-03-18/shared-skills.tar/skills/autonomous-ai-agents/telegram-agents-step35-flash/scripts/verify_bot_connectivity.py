#!/usr/bin/env python3
"""Verify all GenTech Telegram bots can deliver messages to their configured home channels.

Performs a connectivity check by attempting to send a test message to each agent's
TELEGRAM_HOME_CHANNEL using that agent's bot token. Reports success/failure per agent.

Usage: python3 verify_bot_connectivity.py

Exit codes:
  0 - All agents connected successfully
  1 - One or more agents failed (check output)
"""

import json
import os
import ssl
import sys
import urllib.request
import urllib.parse

HOME = os.path.expanduser('~')
PROFILES = ['gentech', 'desmond', 'dmob', 'yoyo']

# Disable SSL verification for Hermes environment
ssl_context = ssl._create_unverified_context()


def load_env_token_and_channel(profile):
    env_path = os.path.join(HOME, '.hermes', 'profiles', profile, '.env')
    token = None
    channel = None
    if not os.path.exists(env_path):
        return None, None
    with open(env_path) as f:
        for line in f:
            if line.startswith('TELEGRAM_BOT_TOKEN'):
                token = line.strip().split('=', 1)[1].strip().strip("'\"")
            elif line.startswith('TELEGRAM_HOME_CHANNEL'):
                channel = line.strip().split('=', 1)[1].strip().strip("'\"")
    return token, channel


def send_test_message(token, channel, profile):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    text = f"✅ {profile} connectivity check — if you see this, channel config is correct"
    data = urllib.parse.urlencode({
        'chat_id': channel,
        'text': text
    }).encode()

    try:
        req = urllib.request.Request(url, data=data, method='POST')
        with urllib.request.urlopen(req, context=ssl_context, timeout=10) as r:
            resp = json.loads(r.read())
            msg_id = resp['result']['message_id']
            chat_title = resp['result'].get('chat', {}).get('title', channel)
            return True, msg_id, chat_title
    except Exception as e:
        return False, str(e), None


def main():
    print("=== GenTech Telegram Bot Connectivity Check ===\\n")
    all_ok = True

    for profile in PROFILES:
        token, channel = load_env_token_and_channel(profile)
        if not token or not channel:
            print(f"❌ {profile}: missing token or channel in .env")
            all_ok = False
            continue

        ok, result, chat_title = send_test_message(token, channel, profile)
        if ok:
            print(f"✅ {profile}: message sent to '{chat_title}' (channel: {channel})")
        else:
            print(f"❌ {profile}: FAILED to send to {channel} — {result}")
            all_ok = False

    print()
    if all_ok:
        print("✓ All bots can reach their home channels.")
        return 0
    else:
        print("✗ Some bots failed. Check TELEGRAM_HOME_CHANNEL values and bot membership.")
        return 1


if __name__ == '__main__':
    sys.exit(main())
