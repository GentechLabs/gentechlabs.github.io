---
name: telegram-agents-step35-flash
description: "Configure GenTech Telegram agent profiles to use stepfun/step-3.5-flash model with Nous provider and set auxiliary vision model."
version: 1.0.0
author: Hermes Agent + Jordan (GenTech)
license: MIT
metadata:
  hermes:
    tags: [telegram, step-3.5-flash, nous, multi-agent, gentech, model-switch]
    related_skills: [hermes-agent, multi-agent-profile-setup]
---

# Telegram Agents — Step 3.5 Flash + Vision Configuration

Apply the StepFun Step-3.5-Flash model (via Nous provider) across all GenTech Telegram agent profiles and configure it as the default auxiliary vision model for photos/media.

## When to Use

- Restoring GenTech agent fleet after provider/model change
- Upgrading all agents from legacy models (mimo-v2.5, kimi-k2.6, ollama-cloud) to Step 3.5 Flash
- Fixing broken auxiliary vision configuration after migration
- Bulk-switching model/provider for all profiles simultaneously
- Recovering from corrupted profile configs (YAML errors)
- Re-syncing Nous OAuth credentials across all agent profiles

## Prerequisites

1. **Nous account authenticated** — ensure you have a valid Nous OAuth session:
   ```bash
   hermes auth list | grep nous
   ```
   If missing, run `hermes model` → select Nous provider → complete OAuth device flow.

2. **Telegram bots already provisioned** — each agent must have its own bot token from @BotFather already in `~/.hermes/profiles/<name>/.env`:
   - `TELEGRAM_BOT_TOKEN` — unique per agent
   - `TELEGRAM_ALLOWED_USERS` — comma-separated user IDs (e.g., `7105876857,6842745592,8774981477`)
   - `TELEGRAM_HOME_CHANNEL` — delivery target for cron jobs

3. **Obsidian vault linked** — `OBSIDIAN_VAULT_PATH` set in each profile's `.env` (optional but expected for GenTech)

4. **Gateway stopped** — stop all running gateways before bulk config changes:
   ```bash
   for p in desmond dmob gentech yoyo; do
     hermes -p $p gateway stop
   done
   ```

## What This Skill Does

1. **Fixes YAML corruption** in profile configs (common after manual edits)
2. **Updates model and provider** for all profiles to `stepfun/step-3.5-flash` (provider: `nous`)
3. **Removes ollama-specific keys** (`base_url`, `api_key`, `api_mode`) left behind from previous provider
4. **Sets auxiliary vision model** to `stepfun/step-3.5-flash` (provider: `nous`) both globally and per-profile
5. **Copies Nous OAuth credentials** from global `~/.hermes/auth.json` into each profile's `auth.json`
6. **Updates all cron job overrides** — finds any job with explicit `model` or `provider` fields and forces them to `step-3.5-flash/nous`
7. **Restarts all gateways** to apply changes
8. **Verifies connectivity** — confirms Telegram connections are alive

## Step-by-Step Workflow

### Phase 1 — Pre-flight checks
```bash
# 1. Confirm global model
grep "^default:" ~/.hermes/config.yaml

# 2. Verify Nous auth present in main auth
hermes auth list | grep nous -A2

# 3. Stop gateways
for p in desmond dmob gentech yoyo; do
  hermes -p $p gateway stop
done
```

### Phase 2 — Execute the skill (automated)
The skill performs all config updates automatically:

- Patch each profile's `config.yaml`:
  - model → `stepfun/step-3.5-flash`
  - provider → `nous`
  - auxiliary.vision.provider → `nous`
  - auxiliary.vision.model → `stepfun/step-3.5-flash`

- Copy Nous credential pool to each `~/.hermes/profiles/<name>/auth.json`

- Rewrite any cron job overrides:
  ```json
  { "model": "old-model", "provider": "old-provider" }
    →
  { "model": "stepfun/step-3.5-flash", "provider": "nous" }
  ```

- Restart each gateway service

### Phase 3 — Post-deploy verification
```bash
# 1. All gateways running?
systemctl --user status hermes-gateway-*.service | grep Active

# 2. Telegram connected?
tail -20 ~/.hermes/profiles/gentech/logs/gateway.log | grep -i "Connected to Telegram"

# 3. Model confirmed across profiles?
for p in desmond dmob gentech yoyo; do
  grep -A1 "^model:" ~/.hermes/profiles/$p/config.yaml
done

# 4. Aux vision set?
grep -A7 "^auxiliary:" ~/.hermes/profiles/gentech/config.yaml | head -10
```

## Role-Specific Agent Mappings (GenTech)

| Profile | Role | Telegram Group | Model |
|---------|------|----------------|-------|
| `gentech` | CEO | Gentech HQ (stepfun) | step-3.5-flash |
| `yoyo` | Strategies | YoYo/Strategies | step-3.5-flash |
| `dmob` | Labs/Dev | DMOB/Labs | step-3.5-flash |
| `desmond` | Creative | Desmond/Entertainment | step-3.5-flash |

## Common Pitfalls & Fixes

- **YAML corruption in profiles** — caused by manual edit errors; the skill auto-fixes by replacing broken `auxiliary` blocks with valid structure
- **Missing Nous credentials in profiles** — profiles do NOT inherit global auth; skill copies `credential_pool['nous']` into each `auth.json`
- **Cron jobs with hardcoded model overrides** — by default, jobs inherit the profile model; legacy jobs with explicit `model`/`provider` fields need their overrides replaced
- **Gateway fails to start** — check `~/.hermes/profiles/<name>/logs/gateway.log` for `Hermes is not logged into Nous Portal.` → run `hermes model` to re-auth
- **Step-3.5-Flash lacks vision** — if image analysis fails, confirm model is multimodal. If not, switch `auxiliary.vision.model` to `openai/gpt-4o` or another vision-capable model via `hermes config set auxiliary.vision.model <model>`
- **Nous OAuth token expiry (15-minute access tokens)** — See detailed section below.
- **Refresh cron job failure (revoked refresh token)** — The `*/10 * * * *` proactive refresh job can fail if the refresh token itself is invalid (expired >24h unused or manually revoked). The job will repeatedly return `RuntimeError: Refresh session has been revoked` without auto-recovery. **Symptoms:** `check_nous_token_expiry.py` shows all profiles `EXPIRED` even though cron is running. **Fix:** Complete a fresh device OAuth (`hermes model` or device flow snippet), then **immediately run the sync+restart script** (see Quick Reference) to force-propagate fresh credentials to all profiles; do not wait for the next cron tick.
- **Telegram delivery failure in cron jobs** — Cron jobs with `deliver: telegram:<channel>` may fail with `Chat not found` if the agent's bot is not a member of that channel or the channel ID is wrong. This does **not** affect the core job work; only prevents Telegram notifications. To fix, ensure the bot is in the target channel and the channel ID is correct. For private groups, the bot must be added as an administrator or member. Test with `/myid` inside Telegram to confirm bot identity.
- **Telegram delivery errors in cron logs** — Cron jobs that `deliver: telegram:<channel>` may fail with `Chat not found` if the agent's bot is not a member of that channel or the channel ID is wrong. This does not affect the job's core work; only prevents Telegram notifications. Verify the bot is in the target channel and the channel ID matches the one in `TELEGRAM_HOME_CHANNEL` or the job's deliver target.

### Nous OAuth Token Expiry (15-minute access tokens)

Nous Portal issues **short-lived access tokens** (TTL = 15 minutes). When they expire, all cron jobs and gateway API calls fail with `Hermes is not logged into Nous Portal.` The gateways have cached credentials and will continue working until they attempt to use the expired token or restart. If the gateway restarts after expiry, it will fail to start until credentials are refreshed.

The **refresh token** can also become invalid (revoked) if unused for >24 hours or after a manual revocation on the Nous Portal. In that state, even with a valid access token in memory, the gateway cannot obtain a new one and will fail after the current access token expires.

**Diagnosis:** Use `check_nous_token_expiry.py` to see expiry status across all profiles. If any show `EXPIRED`, the gateway logs for that profile will contain `RuntimeError: Hermes is not logged into Nous Portal.`

**Recovery:** See "Full Revived-Token Recovery" section below.

### Non-Interactive Recovery (Within Agent Context)

When you can't drop to a shell to run `hermes model` (e.g., you're already operating via a Telegram agent), manually trigger the device flow:

1. **Generate a fresh device auth URL** (from any Python-capable context):
```python
import urllib.request, urllib.parse, json
portal = "https://portal.nousresearch.com"
data = urllib.parse.urlencode({
    "client_id": "hermes-cli",
    "scope": "inference:mint_agent_key"
}).encode()
req = urllib.request.Request(f"{portal}/api/oauth/device/code", data=data,
    headers={"Content-Type": "application/x-www-form-urlencoded"})
with urllib.request.urlopen(req, timeout=10) as r:
    d = json.loads(r.read())
    print(f"URL: {d['verification_uri_complete']}")
    print(f"Code: {d['user_code']}")
```

2. **Open the URL in your browser** and approve the access.
3. **Once approved**, run the credential sync from within your agent session (e.g., ask the agent to execute the skill's bulk update or manually copy `~/.hermes/auth.json` → each `~/.hermes/profiles/*/auth.json`).
4. **Restart gateways** for all affected profiles.
**Note:** The device code expires in 600s; approval must happen quickly.

### Full Revived-Token Recovery (Post-Device-Flow)

After completing a fresh device OAuth (either via `hermes model` or the non-interactive snippet above), you must **manually sync credentials and restart all gateways** — the agents will not pick up the new tokens automatically if their cached credentials are expired.

**One-liner to sync + restart all 4 agents:**
```bash
# Re-auth first via hermes model or device flow, then:
python3 -c "
import json, subprocess, os
home = os.path.expanduser('~/.hermes')
with open(f'{home}/auth.json') as f: global_auth = json.load(f)
nous_cred = global_auth['credential_pool']['nous']
for prof in ['gentech','desmond','dmob','yoyo']:
    path = f'{home}/profiles/{prof}/auth.json'
    with open(path) as f: p = json.load(f)
    p['credential_pool']['nous'] = nous_cred
    with open(path, 'w') as f: json.dump(p, f, indent=2)
    subprocess.run(['hermes','-p',prof,'gateway','restart'])
"
```

**Manual step-by-step:**
```bash
# 1. Verify global token is fresh (check ~/.hermes/auth.json or run check_nous_token_expiry.py)
# 2. Sync global Nous credentials to all profiles (copy credential_pool['nous'])
# 3. Restart each gateway: hermes -p <profile> gateway restart
# 4. Wait ~10s, then verify with check_nous_token_expiry.py — all should show "Valid"
```

**Important:** Even with a fresh global token, profiles with expired cached credentials will continue to fail until you either restart their gateways or manually overwrite their `auth.json`. The proactive refresh cron job only updates profiles on its next schedule tick; it does not push instantly.

### Quick Token Expiry Diagnosis

```bash
# One-liner: profile auth token status across GenTech agents
python3 -c "
import json, os, datetime
home = os.path.expanduser('~/.hermes/profiles')
now = datetime.datetime.now(datetime.timezone.utc)
for prof in ['gentech','desmond','dmob','yoyo']:
    a = json.load(open(f'{home}/{prof}/auth.json'))
    cred = a.get('credential_pool',{}).get('nous',[{}])[0]
    exp = cred.get('expires_at','unknown')
    status = 'OK' if exp != 'unknown' and datetime.datetime.fromisoformat(exp.replace('Z','+00:00')) > now else 'EXPIRED'
    print(f'{prof}: nous credential → {status} (expires: {exp}' + (')' if exp != 'unknown' else ')')
"
```

If any agent shows `EXPIRED`, stop its gateway, re-auth via `hermes model`, then restart.

## Rate Limiting Considerations

All agents sharing a single Nous OAuth token may hit concurrent-request limits. Mitigation strategies:

1. **Stagger cron schedules** — offset per-agent cron minutes (e.g., gentech `:00`, yoyo `:01`, dmob `:02`, desmond `:03`) to avoid thundering herds
2. **Run gateways with staggered restarts** — already handled by systemd randomized delay
3. **Monitor logs** for `"rate limit"` or `"concurrent"` errors in gateway.log

### Gateway Notification Interval (`gateway_notify_interval`)

The `agent.gateway_notify_interval` setting controls how often the gateway sends "still working" progress notifications during long-running tasks (default: `180` seconds). This is the primary rate-control knob for gateway-originated messages; increasing it reduces notification volume (useful when experiencing provider 429s), while decreasing it restores normal cadence.

**Check current value across all profiles:**
```bash
python3 -c "
import yaml, os
home = os.path.expanduser('~/.hermes/profiles')
for prof in ['gentech','desmond','dmob','yoyo']:
    cfg = yaml.safe_load(open(f'{home}/{prof}/config.yaml'))
    print(f'{prof}: {cfg[\"agent\"][\"gateway_notify_interval\"]} seconds')
"
```

**Reset to default (normal operation):**
```bash
for prof in gentech desmond dmob yoyo; do
  sed -i 's/^\\s*gateway_notify_interval:\\s*600/gateway_notify_interval: 180/' ~/.hermes/profiles/$prof/config.yaml
done

# Restart gateways to apply
for prof in gentech desmond dmob yoyo; do
  hermes -p $prof gateway restart
done
```

**Verify reset took effect:**
```bash
# 1. Config values
grep -H 'gateway_notify_interval' ~/.hermes/profiles/*/config.yaml

# 2. Live gateway logs (last few lines should show cron ticker started, not an explicit interval print —
#    the interval is applied at runtime; absence of 600-valued logs and normal cron activity confirms)
tail -3 ~/.hermes/profiles/gentech/logs/gateway.log | grep 'Cron ticker started'
```

**When to adjust:**
- **Increase to 600s** temporarily if you see persistent 429 errors from the provider during heavy cron periods.
- **Reset to 180s** (default) when using a faster/more reliable model like Step 3.5 Flash, or once cron staggering is in place.

**Important:** This is a per-profile setting; ensure all four agent configs are kept consistent unless you have a specific reason to stagger notification intervals separately from cron schedules.

## Reverting to Previous Model

To roll back (e.g., to `mimo-v2.5` via `opencode-go`):

```bash
# Option A — use hermes model wizard (interactive):
for p in desmond dmob gentech yoyo; do
  hermes -p $p model  # pick provider + model
done

# Option B — bulk patch via script (non-interactive):
python3 -c "
import yaml, os
profiles = ['desmond','dmob','gentech','yoyo']
home = os.path.expanduser('~/.hermes/profiles')
for prof in profiles:
  cfg = yaml.safe_load(open(f'{home}/{prof}/config.yaml'))
  cfg['model']['default'] = 'mimo-v2.5'
  cfg['model']['provider'] = 'opencode-go'
  cfg['model']['base_url'] = 'https://inference-api.nousresearch.com/v1'
  with open(f'{home}/{prof}/config.yaml','w') as f:
    yaml.dump(cfg, f, sort_keys=False)
"
```

---

## Ongoing Maintenance — Proactive OAuth Token Refresh

### Problem
Nous Portal issues **short-lived access tokens** (TTL = 15 minutes). When they expire, all cron jobs fail with `RuntimeError: Hermes is not logged into Nous Portal.` The gateways have cached credentials and will continue working until they attempt to use the expired token or restart. If the gateway restarts (system update, manual intervention) and the token is expired, the gateway will fail to start.

Additionally, the **refresh token** can become invalid (revoked) if unused for >24 hours or after a manual token revocation on the Nous Portal. In that state, even with a valid access token in memory, the gateway cannot obtain a new one and will fail after the current access token expires.

### Solution: Proactive Refresh Cron Job

Set up a cron job that runs **every 10 minutes** to refresh the Nous OAuth token *before* it expires. This job:

1. Calls `refresh_nous_oauth_from_state()` using the global Nous credential in `~/.hermes/auth.json`
2. Updates both the global `auth.json` and each agent profile's `auth.json`
3. Ensures even if gateways are restarted, they always load fresh credentials

### Setup

The script is already deployed at `~/.hermes/scripts/refresh_nous_oauth.py`. To create the cron job:

```bash
# From your host (not inside an agent session)
hermes -p gentech cron create '*/10 * * * *' \
  'Run proactive Nous OAuth token refresh to prevent auth expiry.' \
  --name 'Nous OAuth Proactive Refresh' \
  --deliver origin \
  --script refresh_nous_oauth.py
```

The job is now scheduled to run every 10 minutes on the `gentech` profile's gateway (which is always running). It syncs fresh credentials to all four profiles automatically.

### Monitoring

If the refresh job fails, check:

```bash
# Check gentech agent log for refresh output
tail -50 ~/.hermes/profiles/gentech/logs/agent.log | grep -i 'refresh\|nous\|oauth'
```

Successful refresh logs include:
```
=== Nous OAuth Proactive Refresh ===
Refreshing global Nous OAuth token...
✓ Global auth.json updated
✓ Token refreshed, expires at: 2026-05-03T11:58:18.023757+00:00
✓ Synced Nous credentials to gentech
...
```

### Manual Recovery (When Refresh Token is Revoked)

If the refresh script fails with `Refresh session has been revoked` or the device flow returns 404, your refresh token is dead. You must complete a fresh OAuth device flow:

1. Run: `hermes model` (interactive, in your terminal)
2. Open the displayed URL in your browser
3. Approve the access
4. The refresh cron job will automatically pick up the fresh token on its next run

**Non-interactive fallback** (when you can't access a shell directly, e.g., you're only connected via Telegram agent): use the Python snippet from the "Non-Interactive Recovery" section below to generate the device auth URL, approve via a browser on any device, then trigger the refresh cron manually (`hermes -p gentech cron run <job-id>`).

### Token Expiry Diagnosis

```bash
# Check expiry status for all profiles
python3 ~/.hermes/skills/autonomous-ai-agents/telegram-agents-step35-flash/scripts/check_nous_token_expiry.py
```

### Automated Full Recovery (One-Command)

When multiple agents have expired tokens and you're inside an agent session (cannot drop to shell for `hermes model`), use the bundled automated recovery script:

```bash
# Run from any Python-capable context (inside agent or host)
python3 ~/.hermes/skills/autonomous-ai-agents/telegram-agents-step35-flash/scripts/auto_recover_and_restart.py
```

The script:
1. Detects expired tokens across all 4 profiles
2. Generates a fresh OAuth device code and prints URL + user code
3. Waits for you to press ENTER after approving in your browser
4. Syncs fresh global Nous credentials to every agent profile
5. Restarts all 4 gateways
6. Verifies every token is valid and Telegram connected

**Exit code 0 = full success**, non-zero = check logs/steps.

**Note:** The device code expires in 600 seconds; approve promptly after the script prints the URL.

### Emergency Re-Run of Failed Cron Jobs

When auth is restored, manually re-trigger all jobs that failed during the outage:

```bash
python3 -c "
import json, subprocess, os
home = os.path.expanduser('~/.hermes/profiles')
for prof in ['gentech','desmond','dmob','yoyo']:
    jobs = json.load(open(f'{home}/{prof}/cron/jobs.json')).get('jobs',[])
    for job in jobs:
        subprocess.run(['hermes','-p',prof,'cron','run',job['id']])
"
```

This immediately queues all jobs for execution on the next scheduler tick (not阻塞, just schedules them).

## Verification Checklist

- [ ] All 4 gateways active (`systemctl --user status hermes-gateway-*`)
- [ ] Telegram connected in each profile's `logs/gateway.log` (last 5 lines: `Connected to Telegram`)
- [ ] Each profile `config.yaml` shows `model: stepfun/step-3.5-flash` and `provider: nous`
- [ ] Each profile `config.yaml` `auxiliary.vision` set to `nous/stepfun/step-3.5-flash`
- [ ] Global `~/.hermes/config.yaml` `auxiliary.vision` matches
- [ ] Each profile `auth.json` contains a `credential_pool['nous']` entry
- [ ] Cron job listings (`hermes -p <name> cron list`) show no model/provider overrides (or if present, they are step-3.5-flash/nous)
- [ ] Agents respond in Telegram within 10 seconds of a test message

## Files Modified by This Skill

| File | Purpose |
|------|---------|
| `~/.hermes/config.yaml` | Global auxiliary.vision configuration |
| `~/.hermes/profiles/*/config.yaml` | Per-agent model, provider, auxiliary.vision |
| `~/.hermes/profiles/*/auth.json` | Per-agent credential_pool (Nous OAuth) |
| `~/.hermes/profiles/*/cron/jobs.json` | Batch-update overridden model/provider fields |

## Related Skills

- [`hermes-agent`](skill:hermes-agent) — Full CLI reference, gateway commands, config options
- [`multi-agent-profile-setup`](skill:multi-agent-profile-setup) — Initial multi-agent provisioning, Telegram bot setup, credential distribution, cron staggering

## Quick Reference Commands

```bash
# Stop / start all agents
for p in desmond dmob gentech yoyo; do
  hermes -p $p gateway stop && hermes -p $p gateway start
done

# View all agent statuses
systemctl --user status hermes-gateway-*.service --no-pager

# Tail logs for debugging
tail -f ~/.hermes/profiles/gentech/logs/gateway.log

# Test a profile's model
hermes -p gentech chat -q "What model are you using?"

# Re-authenticate Nous if required
hermes model  # → select Nous provider, follow OAuth flow

# Check gateway_notify_interval across all profiles
python3 ~/.hermes/skills/autonomous-ai-agents/telegram-agents-step35-flash/scripts/check_gateway_interval.py

# Check Nous OAuth token expiry across all profiles
python3 ~/.hermes/skills/autonomous-ai-agents/telegram-agents-step35-flash/scripts/check_nous_token_expiry.py

# Reset gateway_notify_interval to default (180) and restart gateways
python3 ~/.hermes/skills/autonomous-ai-agents/telegram-agents-step35-flash/scripts/check_gateway_interval.py --reset

# AFTER re-auth: force-sync fresh credentials to all profiles and restart gateways
python3 ~/.hermes/skills/autonomous-ai-agents/telegram-agents-step35-flash/scripts/sync_nous_credentials_and_restart.py

# Manual one-liner alternative (no script)
python3 -c "
import json, subprocess, os
home = os.path.expanduser('~/.hermes')
with open(f'{home}/auth.json') as f: global_auth = json.load(f)
nous_cred = global_auth['credential_pool']['nous']
for prof in ['gentech','desmond','dmob','yoyo']:
    path = f'{home}/profiles/{prof}/auth.json'
    with open(path) as f: p = json.load(f)
    p['credential_pool']['nous'] = nous_cred
    with open(path, 'w') as f: json.dump(p, f, indent=2)
    subprocess.run(['hermes','-p',prof,'gateway','restart'])
"
```
