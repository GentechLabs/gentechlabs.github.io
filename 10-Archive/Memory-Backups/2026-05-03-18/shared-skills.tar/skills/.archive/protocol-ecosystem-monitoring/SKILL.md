---
name: protocol-ecosystem-monitoring
description: "Automated bi-weekly/monthly research for blockchain protocol ecosystems: track stats, SDK updates, GitHub activity, security risks, and build opportunities. Outputs structured reports for smart contract teams."
version: 1.0.0
author: DMOB
license: MIT
metadata:
  hermes:
    tags: [blockchain, protocol, research, sdk, security, git, npm, go, python, rust]
    related_skills: [hackathon-research-tracking, base, solana]
prerequisites:
  commands: [curl, jq, npm, git, gh]
  environment_variables: []
---

# Protocol Ecosystem Monitoring

Automated bi-weekly/monthly research for blockchain protocol ecosystems. Tracks stats, SDK updates, GitHub activity, security risks, and build opportunities for smart contract teams.

## When to Use

- Scheduled cron job: "Bi-weekly x402 ecosystem check"
- Jordan says: "Check the state of [protocol] ecosystem"
- Jordan says: "Research [protocol] SDK updates"
- Jordan says: "Monitor [protocol] for breaking changes"
- Pre-hackathon prep: Identify protocol gaps for PoCs
- Security audit prep: Track CVEs or exploits in protocol SDKs

## Supported Protocols

| Protocol | Example Chains | Key Tools |
|----------|----------------|-----------|
| x402     | Base, Solana, Polygon, Algorand | `@dexterai/x402`, `x402-foundation/x402` |
| ERC-4337 | Ethereum, Arbitrum, Optimism | `eth-infinitism/account-abstraction` |
| SPL      | Solana | `@solana/spl-token`, `solana-program-library` |
| CosmWasm | Cosmos, Osmosis | `cosmwasm/cw-plus` |
| ICP      | Internet Computer | `dfinity/agent-rs` |

## Phase 1: Protocol Stats

### Official Website

```bash
# Navigate to protocol homepage (e.g., x402.org)
browser_navigate "https://[protocol].org"

# Extract stats: transactions, volume, buyers, sellers
# Look for: "LAST 30 DAYS", "PLATFORM STATISTICS", or similar
```

### Key Data Points

| Field | Why It Matters |
|-------|---------------|
| Transactions (30d) | Adoption velocity |
| Volume (30d) | Economic activity |
| Buyers/Sellers | Network health |
| Ecosystem partners | Integration surface |

## Phase 2: SDK Updates

### npm (JavaScript/TypeScript)

```bash
# Get latest version, dist-tags, and changelog (if available)
npm view @[scope]/[package] version dist-tags changelog --json

# Example: Dexter x402 SDK
npm view @dexterai/x402 version dist-tags --json
```

### GitHub Releases

```bash
# Get latest release tag and body (breaking changes, features)
curl -s "https://api.github.com/repos/[org]/[repo]/releases/latest" | jq -r '.tag_name, .body'

# Compare two tags for changelog diff
curl -s "https://api.github.com/repos/[org]/[repo]/compare/[old]...[new]" | jq -r '.commits[].commit.message'

# Example: x402 foundation
curl -s "https://api.github.com/repos/x402-foundation/x402/releases/latest" | jq -r '.tag_name, .body'
```

### Breaking Change Detection

**Red flags in changelogs**:
- "BREAKING CHANGE:"
- "deprecated"
- "removed"
- "migration guide"
- "backward incompatible"

## Phase 3: GitHub Activity

### Protocol Repo

```bash
# Recent commits (last 5)
curl -s "https://api.github.com/repos/[org]/[repo]/commits?per_page=5" | jq -r '.[].commit.message'

# Example: x402 foundation
curl -s "https://api.github.com/repos/x402-foundation/x402/commits?per_page=5" | jq -r '.[].commit.message'
```

### Ecosystem Repos

```bash
# Search for new SDKs, facilitators, or infra
curl -s "https://api.github.com/search/repositories?q=[protocol]+fork:true+stars:>5&per_page=5" | jq -r '.items[] | "\(.full_name) - \(.stargazers_count) stars"

# Example: x402 facilitators
curl -s "https://api.github.com/search/repositories?q=x402+facilitator+fork:true+stars:>5&per_page=5" | jq -r '.items[] | "\(.full_name) - \(.stargazers_count) stars"'
```

## Phase 4: Security Risks

### Audit Reports

```bash
# Search for audits in GitHub
curl -s "https://api.github.com/search/code?q=filename:audit+repo:[org]/[repo]" | jq -r '.items[] | "\(.html_url)"'

# Example: x402 audits
curl -s "https://api.github.com/search/code?q=filename:audit+repo:x402-foundation/x402" | jq -r '.items[] | "\(.html_url)"'
```

### Known Vulnerabilities

```bash
# Search for CVEs or exploits in GitHub issues
curl -s "https://api.github.com/search/issues?q=repo:[org]/[repo]+label:security" | jq -r '.items[] | "\(.title) - \(.html_url)"'

# Example: x402 CVEs
curl -s "https://api.github.com/search/issues?q=repo:x402-foundation/x402+label:security" | jq -r '.items[] | "\(.title) - \(.html_url)"'
```

## Phase 5: Ecosystem Adoption

### New Facilitators/Integrations

```bash
# Check protocol.org/ecosystem for new partners
browser_navigate "https://[protocol].org/ecosystem"

# Example: x402.org ecosystem partners
browser_navigate "https://x402.org"
browser_click "[ref to ecosystem section]"
```

### Chain-Specific Activity

```bash
# Base chain (EVM)
curl -s "https://api.github.com/search/repositories?q=[protocol]+base+chain&sort=updated&order=desc&per_page=5"

# Solana (SPL)
curl -s "https://api.github.com/search/repositories?q=[protocol]+solana&sort=updated&order=desc&per_page=5"

# Example: x402 on Base
curl -s "https://api.github.com/search/repositories?q=x402+base+chain&sort=updated&order=desc&per_page=5"
```

## Phase 6: Build Opportunities

### Hackathon Ideas

```markdown
- **PoC**: [Protocol] Facilitator on [Chain]
  - **Why**: First-mover advantage (e.g., x402 on Avalanche)
  - **Stack**: [Language] SDK, [Chain] RPC
  - **Differentiation**: Add [feature] (e.g., dispute resolution, reputation)

- **Tool**: [Protocol] SDK Auditor
  - **Why**: Test for breaking changes or adversarial queries
  - **Output**: CLI to flag deprecated methods or security risks

- **Integration**: [Protocol] + [Sponsor API]
  - **Example**: x402 + Quicknode RPC
  - **Judge Appeal**: Sponsor alignment
```

### Long-Term Plays

```markdown
- **Middleware**: Wrap [Protocol] SDK for [Use Case]
  - **Example**: AgentEscrow x402 middleware for dispute resolution
- **Cross-Chain Router**: Route [Protocol] payments via [Chain A], settle disputes on [Chain B]
- **TEE Integration**: Partner with [Provider] for secure [Protocol] signing
```

## Phase 7: Report Format

```markdown
## [Protocol] Ecosystem Research — [Date]

### 📊 Stats (Last 30 Days vs Previous)
- **Transactions**: [X] (+[Y]%)
- **Volume**: $[X] (+[Y]%)
- **Buyers**: [X] (+[Y]%)
- **Sellers**: [X] (+[Y]%)
- **Ecosystem Partners**: [List] *(new: [X])*

### 🆕 What's New
- **SDK Updates**: [Package] `v[X.Y.Z` → `v[A.B.C]`
  - Breaking: [Change 1], [Change 2]
  - Added: [Feature 1], [Feature 2]
- **Protocol Updates**: [Change 1], [Change 2]
- **New Facilitators**: [Name] ([URL], chains: [X], schemes: [Y])
- **Partnerships**: [Partner] + [Protocol] integration

### 🔒 Security
- **New Audits**: [Audit 1] ([URL])
- **Vulnerabilities**: [CVE-XXXX-XXXX] ([Severity], [URL])
- **Risks to Monitor**: [Risk 1], [Risk 2]

### ⚡ Labs Relevance
- **Critical for Our Builds**: [Feature 1], [Feature 2]
- **Gaps to Exploit**: [Gap 1], [Gap 2]

### 🏗️ Build Opportunities
#### Hackathon Ideas
1. **[Idea 1]**: [One-liner]
2. **[Idea 2]**: [One-liner]

#### Long-Term Plays
1. **[Idea 1]**: [One-liner]
2. **[Idea 2]**: [One-liner]

**Next Steps**:
- Update [Project] to use [SDK] `v[X.Y.Z]`
- Draft [PoC] for [Hackathon]
- Monitor [Risk] for exploits
```

## Phase 8: Sync

```bash
cd /root/vaults/gentech && ob sync
```

## Pitfalls

1. **GitHub API rate limits**: Use `gh` CLI or personal access tokens for authenticated requests.
2. **npm view vs npm info**: `npm view` is JSON-friendly; `npm info` is human-readable but harder to parse.
3. **Protocol homepage parsing**: Some sites (e.g., x402.org) require clicking "Ecosystem" to see partners.
4. **SDK changelogs**: Not all packages publish changelogs. Fall back to GitHub release notes.
5. **False positives in GitHub search**: Filter by `stars:>5` to avoid noise.
6. **Security labels**: GitHub issues labeled `security` may not always be CVEs. Verify severity.
7. **Chain-specific quirks**:
   - **Base**: Use `base+chain` in GitHub search.
   - **Solana**: Use `solana+program` or `spl`.
   - **Avalanche**: Often empty — first-mover opportunity.
